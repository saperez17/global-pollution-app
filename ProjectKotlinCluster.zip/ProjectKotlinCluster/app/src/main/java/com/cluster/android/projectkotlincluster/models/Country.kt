package com.cluster.android.projectkotlincluster.models

class Country(
    val name:String,
    val flag:String
)